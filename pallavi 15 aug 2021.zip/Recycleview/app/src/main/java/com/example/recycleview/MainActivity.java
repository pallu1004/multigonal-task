package com.example.recycleview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView rcv;
    myAdapter adapter;
    ArrayList<Model> data;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rcv = (RecyclerView) findViewById(R.id.rclview);
         rcv.setLayoutManager(new LinearLayoutManager(this));


        adapter = new myAdapter(dataqueue(), getApplicationContext());
        rcv.setAdapter(adapter);

        /**GridLayoutManager gridLayoutManager=new GridLayoutManager(this,2);
        rcv.setLayoutManager(gridLayoutManager);*/
    }

    public ArrayList<Model> dataqueue() {
        ArrayList<Model> holder = new ArrayList<>();

        Model ob1=new Model();
        ob1.setT1("Monday");
        ob1.setM1("1. meeting at 1 pm");
        ob1.setM2("2.code implimentation");
        ob1.setM3("3.mail to client");
        ob1.setM4("4.client meet at 2pm");
        holder.add(ob1);

        Model ob2=new Model();
        ob2.setT1("Tuseday");
        ob2.setM1("1.meeting at 2pm");
        ob2.setM2("2.code implimentation");
        ob2.setM3("3.mail to client");
        ob2.setM4("4.client meet at 4pm");
        holder.add(ob2);

        Model ob3=new Model();
        ob3.setT1("Wednesday");
        ob3.setM1("1.meeting at 5pm");
        ob3.setM2("2.code implimentation");
        ob3.setM3("3.mail to client");
        ob3.setM4("4.client meet at 10pm");

        holder.add(ob3);

        Model ob4=new Model();
        ob4.setT1("Thursday");
        ob4.setM1("1.meeting at 4pm");
        ob4.setM2("2.code implimentation");
        ob4.setM3("3.mail to client");
        ob4.setM4("4.client meet at 1pm");

        holder.add(ob4);

        Model ob5=new Model();
        ob5.setT1("Friday");
        ob5.setM1("1.meeting at 12pm");
        ob5.setM2("2.code implimentation");
        ob5.setM3("Animation | Drama | Adventure");
        ob5.setM4("4.client meet at 6pm");

        holder.add(ob5);

        Model ob6=new Model();
        ob6.setT1("Saturday");
        ob6.setM1("1.meeting at 10pm");
        ob6.setM2("2.code implimentation");
        ob6.setM3("3.mail to client");
        ob6.setM4("4.client meet at 3pm");
        holder.add(ob6);



        return holder;



    }
}

