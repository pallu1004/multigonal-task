package com.example.recycleview;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class myAdapter extends RecyclerView.Adapter<myAdapter.holder>{
    ArrayList<Model> data;
    Context context;
    public myAdapter(ArrayList<Model> data, Context context)
    {
        this.data = data;
        this.context=context;
    }



    /** String data[];

     public myAdapter(String[] data)
     {
     this.data = data;
     }*/

    @NonNull
    @Override
    public holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View view=inflater.inflate(R.layout.singlerow,parent,false);
        return new holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull holder holder, int position)

    {
        final Model temp=data.get(position);

        holder.weeks.setText(data.get(position).getT1());


        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent=new Intent(context,MainActivity2.class);



                 intent.putExtra("m1",temp.getM1());
                 intent.putExtra("m2",temp.getM2());
                 intent.putExtra("m3",temp.getM3());
                 intent.putExtra("m4",temp.getM4());



                 intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount()
    {

        return data.size();
    }


    class holder extends RecyclerView.ViewHolder
    {

        TextView weeks;
        LinearLayout linearLayout;

        public holder(@NonNull View itemView) {
            super(itemView);


            weeks= itemView.findViewById(R.id.t1);

            linearLayout=itemView.findViewById(R.id.layout);

        }
    }


}


