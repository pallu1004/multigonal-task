package com.example.recycleview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity
{

    TextView m1,m2,m3,m4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        m1= findViewById(R.id.m1);
        m2= findViewById(R.id.m2);
        m3 = findViewById(R.id.m3);
        m4 = findViewById(R.id.m4);


        m1.setText(getIntent().getStringExtra("m1"));
        m2.setText(getIntent().getStringExtra("m2"));
        m3.setText(getIntent().getStringExtra("m3"));
        m4.setText(getIntent().getStringExtra("m4"));






    }
}